
public class Account {
    
    private String name;
    private String email;
    private double rate;
    private double principal;
    private int year;
    double x;
    
    public Account(String nam , double p , double ratee , int yearr , String emaill){
        
        name = nam;
        principal = p;
        rate = ratee/100;
        year = yearr;
        email = emaill;
    }
    
   double calculatePrincipalWithSimpleInterest(){
       
       x = principal*(1+rate*year);
       return x;
   }
   
   double calculatePrincipalWithCompoundInterest(){
       
       x = principal * Math.pow((1+rate), year);
       return x;
   }
   
   void withdrawMoney(double amount){
       
       if(principal < amount){
           
           System.out.println("Not Possible");
       }
       else{
           
           principal-= amount;
       }
       
   }
   
   double getCurrentBalance(){
       
       return principal;
   }
   
   void changeEmail(String change_email){
       
       email = change_email;
       
   }
   
   String getEmail(){
       
       return email;
   }
    
}

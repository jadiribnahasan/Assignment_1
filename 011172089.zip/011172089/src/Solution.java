
import java.util.Scanner;


public class Solution {
    public static void main(String [] args){
        
        Scanner scan = new Scanner(System.in);
        
     String name;
     String email;
     double rate;
     double principal; //John 100.24 4.5 3 john@gmail.com 130 j@gmail.com
     int year;
     double wd;
     String cemail;
     
     name = scan.next();
     principal = scan.nextDouble();
     rate = scan.nextDouble();
     year = scan.nextInt();
     email = scan.next();
     wd = scan.nextDouble();
     cemail = scan.next();
     
     Account a1 = new Account(name , principal , rate , year , email);
     
     System.out.println(a1.calculatePrincipalWithSimpleInterest());
     System.out.println(a1.calculatePrincipalWithCompoundInterest());
     a1.withdrawMoney(wd);
     System.out.println(a1.getCurrentBalance());
     a1.changeEmail(cemail);
     System.out.println(a1.getEmail());
     
     
     
            
            
        
    }
}
